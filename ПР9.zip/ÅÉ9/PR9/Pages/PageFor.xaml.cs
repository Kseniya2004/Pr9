﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PR9.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageFor.xaml
    /// </summary>
    public partial class PageFor : Page
    {
        public PageFor()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            clsFrame.frmObject.Navigate(new PageDoWhile());
        }

        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
            double X0 = int.Parse(Console.ReadLine());
            double Xk = int.Parse(Console.ReadLine());
            double dX = int.Parse(Console.ReadLine());
            double b = int.Parse(Console.ReadLine());
            for (double x = X0; x<Xk; x+=b)
            {
                double Rez = Math.Pow(x, 5 / 2 - b) * Math.Log(x * x + 12.7);               
            }
        }
    }
}
